﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _0924관리
{
    class Program
    {
        static void Main(string[] args)
        {
            app ap = new app();
            ap.init();
            ap.run();
            ap.exit();
        }
    }
}
