﻿using System;

namespace _0924관리프로그램
{
    class Program
    {          
        static void Main(string[] args)
        {
            app ap = new app();
            ap.init();
            ap.run();
            ap.exit();
        }
    }
}
