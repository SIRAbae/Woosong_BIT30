﻿
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace _1008_scoreMgr
{
    class wbdb
    {
        public SqlConnection conn;
        private String constr1; //교수님
        public String constr2; //나

        public wbdb()
        {
            conn = new SqlConnection();
            constr1 = @"Server=user-pc;database = wb30;uid=ccm;pwd=1234;";
            constr2 = @"Server=192.168.0.50;database = wb30;uid=ssg;pwd=1234;";
            conn.ConnectionString = constr1;
        }

        #region DB조작
        public bool Connect()
        {
            try
            {
                conn.Open();
                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }

        public void DisConnect()
        {
            conn.Close();
        }

        private bool ExSqlCommand(string comstr)
        {
            SqlCommand scom = new SqlCommand();
            scom.Connection = conn;
            scom.CommandText = comstr;
            scom.CommandType = System.Data.CommandType.Text;

            if (scom.ExecuteNonQuery() > 0)     //1) ddl, i,u,d
            {
                scom.Dispose();
                return true;
            }
            scom.Dispose();
            return false;
        }
        #endregion

        #region 데이터 업데이트
        public void AllData(List<ScoreData> list)
        {
            string comtext =
                string.Format("select * from score");
            SqlCommand command = new SqlCommand(comtext, conn);
            SqlDataReader reader = command.ExecuteReader(); //2) s 전용

            while (reader.Read())
            {
                ScoreData s = new ScoreData(
                    int.Parse(reader[0].ToString()),
                    int.Parse(reader[1].ToString()),
                    int.Parse(reader[2].ToString()),
                    int.Parse(reader[3].ToString()),
                    int.Parse(reader[4].ToString()),
                    int.Parse(reader[5].ToString()),
                    reader[6].ToString()
               );

                list.Add(s);
            }

            reader.Close();
            command.Dispose();
        }

        public void ALLSubName(List<string> list)
        {
            string comtext =
                string.Format("select distinct subname from subject");
            SqlCommand command = new SqlCommand(comtext, conn);
            SqlDataReader reader = command.ExecuteReader(); //2) s 전용

            while (reader.Read())
            {
                string s = reader[0].ToString();
                list.Add(s);
            }

            reader.Close();
            command.Dispose();
        }

        public void AllStudent(List<string> list, string sub)
        {
            string comtext =
               string.Format(" select distinct j.sname ,j.SubID from (select s.SubID ,st.SNAME from Score s, Student st where s.SNUM = st.SNUM) as j where j.SubID = (select subID from subject where subName = '{0}')", sub);
            SqlCommand command = new SqlCommand(comtext, conn);
            SqlDataReader reader = command.ExecuteReader(); //2) s 전용

            while (reader.Read())
            {
                string s = reader[0].ToString();
                list.Add(s);
            }

            reader.Close();
            command.Dispose();
        }
        #endregion

        #region 데이터 관리
        public bool InsertScore(string name, string subname, string home, string writing, string practical, string date)
        {
            string str = string.Format("INSERT INTO dbo.Score (Snum, SubID, Home_score, Writing_scor, Practical_scor, Date) VALUES ((select snum from Student where Student.SNAME = '{0}'), (select SubID from Subject where SubName = '{1}'), {2}, {3}, {4}, '{5}')",
                name,subname, home,writing,practical,date);

            return ExSqlCommand(str);
        }

        public bool UpdateScore(string sub, string home, string writing, string practical, string index)
        {
            string str = string.Format("update score set SubID = (select SubID from Subject where SubName = '{0}'), home_score = {1}, writing_scor = {2}, practical_scor={3} where SCORINDEX = {4};",
               sub,home,writing,practical, index);

            return ExSqlCommand(str);
        }

        public bool DeleteScore(string index)
        {
            string str = string.Format("DELETE score WHERE SCORINDEX = {0};",
              index);

            return ExSqlCommand(str);
        }
        #endregion

        #region 데이터 검색
        public void SearchName(List<ScoreData> list,string sname)
        {
            
            string comtext =
               string.Format("Select*  from score where snum = (select snum from student where sname ='{0}')", sname);
            SqlCommand command = new SqlCommand(comtext, conn);
            SqlDataReader reader = command.ExecuteReader(); //2) s 전용

            while (reader.Read())
            {
                ScoreData s = new ScoreData(
                    int.Parse(reader[0].ToString()),
                    int.Parse(reader[1].ToString()),
                    int.Parse(reader[2].ToString()),
                    int.Parse(reader[3].ToString()),
                    int.Parse(reader[4].ToString()),
                    int.Parse(reader[5].ToString()),
                    reader[6].ToString()
               );

                list.Add(s);
            }

            reader.Close();
            command.Dispose();
        }

        public void SearchSub(List<ScoreData> list, string subname)
        {

            string comtext =
               string.Format("Select*  from score where subid = (select subid from subject where subname ='{0}')", subname);
            SqlCommand command = new SqlCommand(comtext, conn);
            SqlDataReader reader = command.ExecuteReader(); //2) s 전용

            while (reader.Read())
            {
                ScoreData s = new ScoreData(
                    int.Parse(reader[0].ToString()),
                    int.Parse(reader[1].ToString()),
                    int.Parse(reader[2].ToString()),
                    int.Parse(reader[3].ToString()),
                    int.Parse(reader[4].ToString()),
                    int.Parse(reader[5].ToString()),
                    reader[6].ToString()
               );

                list.Add(s);
            }

            reader.Close();
            command.Dispose();
        }

        public void SearchAvg(List<Avg> list)
        {

            string comtext =
               string.Format("Select SNUM, avg(scor.home_score + scor.Writing_scor + scor.Practical_scor)개인별과목전체평균 from Score scor group by SNUM order by  avg(scor.home_score + scor.Writing_scor + scor.Practical_scor)");
            SqlCommand command = new SqlCommand(comtext, conn);
            SqlDataReader reader = command.ExecuteReader(); //2) s 전용

            while (reader.Read())
            {
                Avg s = new Avg(
                    int.Parse(reader[0].ToString()),
                    int.Parse(reader[1].ToString())  
               );

                list.Add(s);
            }

            reader.Close();
            command.Dispose();
        }
        #endregion
    }
}