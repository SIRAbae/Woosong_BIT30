﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1008_scoreMgr
{
    public class ScoreData
    {
        public int Score_index { get; set; }
        public int Snum { get; set; }
        public int Subid { get; set; }
        public int Home_score { get; set; }
        public int Writing_score { get; set; }
        public int Practical_score { get; set; }
        public string Date { get; set; }

        public ScoreData(int sindex, int snum, int subid, int homescore, int writingscore,int pracscore, string datescore)
        {
            Score_index = sindex;
            Snum = snum;
            Subid = subid;
            Home_score = homescore;
            Writing_score = writingscore;
            Practical_score = pracscore;
            Date = datescore;
        }
    }
}
