﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1008_scoreMgr
{
    public partial class Form1 : Form
    {
        wbdb wdb;
        public List<ScoreData> scorlist = new List<ScoreData>();
        public List<string> sublist = new List<string>();
        public List<string> studentlist = new List<string>();

        public List<Avg> avglist = new List<Avg>();


        public Form1()
        {
            InitializeComponent();
            wdb = new wbdb();
            wdb.Connect();

           
            wdb.ALLSubName(sublist);
            UpdateScoreData();
            UpdateSubname();
        }


        #region 리스트뷰 디자인
        private void nomal_items()
        {
            listView1.Clear();
            listView1.Columns.Add("인덱스");
            listView1.Columns.Add("학번");
            listView1.Columns.Add("과목번호");
            listView1.Columns.Add("과제점수");
            listView1.Columns.Add("이론점수");
            listView1.Columns.Add("실기점수");
            listView1.Columns.Add("날짜");
        }
        private void avg_items()
        {
            listView1.Clear();
            listView1.Columns.Add("학번");
            listView1.Columns.Add("전체평균");

        }
        #endregion

        #region 데이터 업데이트
        private void UpdateScoreData()
        {
            scorlist.Clear();
            wdb.AllData(scorlist);
            listView1.Items.Clear();
            for (int i = 0; i < scorlist.Count; i++)
            {
                string[] arr = new string[7];

                arr[0] = scorlist[i].Score_index.ToString();
                arr[1] = scorlist[i].Snum.ToString();
                arr[2] = scorlist[i].Subid.ToString();
                arr[3] = scorlist[i].Home_score.ToString();
                arr[4] = scorlist[i].Writing_score.ToString();
                arr[5] = scorlist[i].Practical_score.ToString();
                arr[6] = scorlist[i].Date;

                ListViewItem tem = new ListViewItem(arr);
                listView1.Items.Add(tem);
            }
        }

        private void UpdateSubname()
        {
            for (int i = 0; i < sublist.Count; i++)
            {
                listBox1.Items.Add(sublist[i]);
            }
        }

        private void UpdateStudent()
        {
            for (int i = 0; i < studentlist.Count; i++)
            {
                listBox3.Items.Add(studentlist[i]);
            }
        }

        //과목 누르면 학생출력
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            studentlist.Clear();
            listBox3.Items.Clear();

            int index = listBox1.SelectedIndex;
            string temp = (string)listBox1.Items[index];

            wdb.AllStudent(studentlist, temp);

            UpdateStudent();
        }

        //이름으로 검색
        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                nomal_items();
                string sname;
                int index = listBox3.SelectedIndex;
                string temp = (string)listBox3.Items[index];
                sname = temp;

                scorlist.Clear();
                listView1.Items.Clear();

                wdb.SearchName(scorlist, sname);

                for (int i = 0; i < scorlist.Count; i++)
                {
                    string[] arr = new string[7];

                    arr[0] = scorlist[i].Score_index.ToString();
                    arr[1] = scorlist[i].Snum.ToString();
                    arr[2] = scorlist[i].Subid.ToString();
                    arr[3] = scorlist[i].Home_score.ToString();
                    arr[4] = scorlist[i].Writing_score.ToString();
                    arr[5] = scorlist[i].Practical_score.ToString();
                    arr[6] = scorlist[i].Date;

                    ListViewItem tem = new ListViewItem(arr);
                    listView1.Items.Add(tem);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("이름을 선택하세요.");
            }
            

        }

        //과목으로 검색
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                nomal_items();
                string subname;
                int index = listBox1.SelectedIndex;
                string temp = (string)listBox1.Items[index];
                subname = temp;

                scorlist.Clear();
                listView1.Items.Clear();

                wdb.SearchSub(scorlist, subname);

                for (int i = 0; i < scorlist.Count; i++)
                {
                    string[] arr = new string[7];

                    arr[0] = scorlist[i].Score_index.ToString();
                    arr[1] = scorlist[i].Snum.ToString();
                    arr[2] = scorlist[i].Subid.ToString();
                    arr[3] = scorlist[i].Home_score.ToString();
                    arr[4] = scorlist[i].Writing_score.ToString();
                    arr[5] = scorlist[i].Practical_score.ToString();
                    arr[6] = scorlist[i].Date;

                    ListViewItem tem = new ListViewItem(arr);
                    listView1.Items.Add(tem);
                }
            }
            catch (Exception)
            {
                MessageBox.Show("과목을 선택하세요");
            }
           
        }

        //전체 출력
        private void button7_Click(object sender, EventArgs e)
        {
            nomal_items();
            UpdateScoreData();
        }

        //평균전체출력
        private void button6_Click(object sender, EventArgs e)
        {

            avg_items();
            avglist.Clear();
            wdb.SearchAvg(avglist);

            for (int i = 0; i < avglist.Count; i++)
            {
                string[] arr = new string[2];

                arr[0] = avglist[i].Snum.ToString();
                arr[1] = avglist[i].Avgs.ToString();
                
                ListViewItem tem = new ListViewItem(arr);
                listView1.Items.Add(tem);
            }

        }
        #endregion

        #region 데이터 관리
        //데이터 저장
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string sname, subname, home, writing, practical, date;

                int index = listBox3.SelectedIndex;
                string temp = (string)listBox3.Items[index];
                sname = temp;

                index = listBox1.SelectedIndex;
                temp = (string)listBox1.Items[index];
                subname = temp;

                home = textBox1.Text;
                writing = textBox2.Text;
                practical = textBox3.Text;

                date = DateTime.Now.ToString("yyyy - MM - dd");

                if (wdb.InsertScore(sname, subname, home, writing, practical, date))
                {
                    MessageBox.Show("저장완료");
                    UpdateScoreData();
                }
            }
            catch(Exception)
            {
                MessageBox.Show("저장실패 : 올바른 값을 확인하세요");
            }
            
        }

        //데이터 수정
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string sub, home, writing, practical, index;

                int indexd = listBox1.SelectedIndex;
                string temp = (string)listBox1.Items[indexd];
                sub = temp;

                home = textBox1.Text;
                writing = textBox2.Text;
                practical = textBox3.Text;

                indexd = listView1.FocusedItem.Index;
                temp = listView1.Items[indexd].SubItems[0].Text;
                index = temp;

                if (wdb.UpdateScore(sub, home, writing, practical, index))
                {
                    MessageBox.Show("저장완료");
                    UpdateScoreData();
                }
            }
            catch(Exception)
            {
                MessageBox.Show("수정실패");
            }
            
            
        }

        //데이터 삭제
        private void button3_Click(object sender, EventArgs e)
        {

            try
            {
                string index;

                int indexd = listView1.FocusedItem.Index;
                string temp = listView1.Items[indexd].SubItems[0].Text;
                index = temp;

                if (wdb.DeleteScore(index))
                {
                    MessageBox.Show("삭제완료");
                    UpdateScoreData();
                }
            }
            catch (Exception)
            {
                MessageBox.Show("삭제할 대상을 선택하세요");
            }
            
        }

        #endregion

       
    }
}
