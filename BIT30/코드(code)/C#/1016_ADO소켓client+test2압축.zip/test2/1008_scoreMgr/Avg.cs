﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1008_scoreMgr
{
    public class Avg
    {
        public int Snum { get; set; }
        public int Avgs { get; set; }


        public Avg(int snum, int avg)
        {
            Snum = snum;
            Avgs = avg;
        }
    }
}
